### Ensemble Methods for Regression Data ###
library(forecast)
library(forecastHybrid)

source("Utilities.R")

# Visualization
windows(height=100,width=150)
plot.ts(AirPassengers)
par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)
plotts(AirPassengers)
legend("topright", inset=c(-0.2,0), "-",
       legend=c(start(AirPassengers)[1]:end(AirPassengers)[1]),
       col=start(AirPassengers)[1]:end(AirPassengers)[1],lty=2)

plot.ts(austres)
windows(height=100,width=150)
par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)
plotts(austres)
legend("topright", inset=c(-0.2,0), "-",
       legend=c(start(austres)[1]:end(austres)[1]),
       col=start(austres)[1]:end(austres)[1],lty=2)

plot.ts(co2)
windows(height=100,width=150)
par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)
plotts(co2)
legend("topright",inset=c(-0.2,0),"-",
       legend=c(c(start(co2)[1]:(start(co2)[1]+3)),". . . ",
                c((end(co2)[1]-3):end(co2)[1])),
       col=c(c(start(co2)[1]:(start(co2)[1]+3)),NULL,
             c((end(co2)[1]-3):end(co2)[1])),lty=2)

windows(height=100,width=300)
par(mfrow=c(1,3))
plot.ts(UKDriverDeaths,main="UK Driver Deaths")
plot.ts(gas,main="Australian monthly gas production")
plot.ts(uspop,main="Populations Recorded by the US Census")


# Time Series Concepts
# The Notion of Auto-regressiveness!
plot(AirPassengers[1:143],AirPassengers[2:144],
     xlab="Previous Observation",
     ylab="Current Observation")
# How many lags? 
windows(height=200,width=200)
par(mfrow=c(2,2))
plot.ts(WWWusage)
plot(WWWusage[1:99],WWWusage[2:100],
     xlab="Previous Observation",
     ylab="Current Observation",main="Lag-1 Plot"
     )
plot(WWWusage[1:98],WWWusage[3:100],
     xlab="Previous Observation",
     ylab="Current Observation",main="Lag-2 Plot"
     )
plot(WWWusage[1:97],WWWusage[4:100],
     xlab="Previous Observation",
     ylab="Current Observation",main="Lag-3 Plot"
     )




# ACF, PACF, CCF
jpeg("ACF_PACF_Plots.jpeg")
par(mfrow=c(2,2))
acf(austres,main="ACF of Austres Data")
pacf(austres,main="PACF of Austres Data")
acf(uspop,main="ACF of US Population")
pacf(uspop,main="PACF of US Population")
dev.off()

CarSales <- read.csv("../Data/Car_Sales.csv")
summary(CarSales)
jpeg("CCF_Car_Sales_Advertising.jpeg")
ccf(x=CarSales$Advertising,y=CarSales$Sales,
    main="Cross Correlation Between Sales and Advertising")
dev.off()

# Accuracy Measurements
co2_sub <- subset(co2,start=1,end=443)
co2_arima <- auto.arima(co2_sub)
summary(co2_arima)
windows(height=100,width=100)
plot(forecast(co2_arima,h=25))
accuracy(forecast(co2_arima,h=25),x=co2[444:468])


# Time Series Models
# Naive Forecast
co2_naive <- naive(co2_sub,h=25,level=c(90,95))
summary(co2_naive)
plot(co2_naive) # Output suppressed
accuracy(forecast(co2_naive,h=25),x=co2[444:468])

# Fit a STL 
AP_stl <- stl(AirPassengers,s.window=frequency(AirPassengers))
summary(AP_stl)
jpeg("STL_Decompose_AirPassengers.jpeg")
plot(AP_stl)
dev.off()
accuracy(forecast(AP_stl))

# Fit a ETS
uspop_sub <- subset(uspop,start=1,end=15)
USpop_ets <- ets(uspop_sub)
summary(USpop_ets)
forecast(USpop_ets,h=4)
plot(forecast(USpop_ets,h=4))
accuracy(forecast(USpop_ets,h=4),x=uspop[16:19])
accuracy(forecast(naive(uspop_sub),h=4),x=uspop[16:19])

# Fit an Auto-regressive NN
gas_sub <- subset(gas,start=1,end=450)
gas_nnetar <- nnetar(gas_sub,p=25,P=12,size=10,repeats=10)
plot(forecast(gas_nnetar,h=26))
accuracy(forecast(gas_nnetar,h=26),x=gas[451:476])

# Bagging and Time Series
# baggedETS from forecast package
uspop_bagg_ets <- baggedETS(uspop_sub,bootstrapped_series = 
                              bld.mbb.bootstrap(uspop_sub, 500))
forecast(uspop_bagg_ets,h=4);subset(uspop,start=16,end=19)
plot(forecast(uspop_bagg_ets,h=4))
accuracy(forecast(USpop_ets,h=4),x=uspop[16:19])
accuracy(forecast(uspop_bagg_ets,h=4),x=subset(uspop,start=16,end=19))

# Ensemble/Hybrid Models
accuracy(forecast(co2_arima,h=25),x=co2[444:468])
AP_Ensemble_02 <- hybridModel(co2_sub,models="ae")
accuracy(AP_Ensemble_02,h=25,x=co2[444:468])
AP_Ensemble_03 <- hybridModel(co2_sub,models="aen")
accuracy(AP_Ensemble_03,h=25,x=co2[444:468])
AP_Ensemble_04 <- hybridModel(co2_sub,models="aens")
accuracy(AP_Ensemble_04,h=25,x=co2[444:468])
AP_Ensemble_05 <- hybridModel(co2_sub,models="aenst")
accuracy(AP_Ensemble_05,h=25,x=co2[444:468])



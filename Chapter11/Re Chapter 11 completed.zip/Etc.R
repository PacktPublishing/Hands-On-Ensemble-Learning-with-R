
# Visualization



#### Code Gone WRONG ########
windows(height=100,width=150)
plot.ts(co2)
par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)
plotts(co2)
legend("topright", inset=c(-0.2,0), "-",legend=c(start(co2)[1]:end(co2)[1]),
       col=start(co2)[1]:end(co2)[1],lty=2)

windows(height=100,width=175)
par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)
plotts(co2)
legend_order <- matrix(1959:1997,ncol=3,byrow = TRUE)
legend("topright", inset=c(-0.2,0), "-",bty="n",
                           legend=c(start(co2)[1]:end(co2)[1])[legend_order],
                           col=c(start(co2)[1]:end(co2)[1],nrow=3)[legend_order],
                           ncol=3
                           )
#### Code Gone WRONG  upto here ########



# MAPE Accuracy
TS_Info <- data.frame(matrix(0,nrow=21,ncol=9))
names(TS_Info) <- c("Dataset","Length","Frequency","Minimum","Q1","Median","Mean","Q3","Maximum")
TS_Info$Dataset <- c("AirPassengers","BJsales","JohnsonJohnson","LakeHuron","Nile","UKgas","UKDriverDeaths","USAccDeaths","WWWusage","airmiles","austres","co2","discoveries","lynx","nhtemp","nottem","presidents","treering","gas","uspop","sunspots")

A <- NULL
A <- c(A,length(AirPassengers))
A <- c(A,length(BJsales))
A <- c(A,length(JohnsonJohnson))
A <- c(A,length(LakeHuron))
A <- c(A,length(Nile))
A <- c(A,length(UKgas))
A <- c(A,length(UKDriverDeaths))
A <- c(A,length(USAccDeaths))
A <- c(A,length(WWWusage))
A <- c(A,length(airmiles))
A <- c(A,length(austres))
A <- c(A,length(co2))
A <- c(A,length(discoveries))
A <- c(A,length(lynx))
A <- c(A,length(nhtemp))
A <- c(A,length(nottem))
A <- c(A,length(presidents))
A <- c(A,length(treering))
A <- c(A,length(gas))
A <- c(A,length(uspop))
A <- c(A,length(sunspots))
TS_Info[,2] <- A
A <- NULL
A <- c(A,frequency(AirPassengers))
A <- c(A,frequency(BJsales))
A <- c(A,frequency(JohnsonJohnson))
A <- c(A,frequency(LakeHuron))
A <- c(A,frequency(Nile))
A <- c(A,frequency(UKgas))
A <- c(A,frequency(UKDriverDeaths))
A <- c(A,frequency(USAccDeaths))
A <- c(A,frequency(WWWusage))
A <- c(A,frequency(airmiles))
A <- c(A,frequency(austres))
A <- c(A,frequency(co2))
A <- c(A,frequency(discoveries))
A <- c(A,frequency(lynx))
A <- c(A,frequency(nhtemp))
A <- c(A,frequency(nottem))
A <- c(A,frequency(presidents))
A <- c(A,frequency(treering))
A <- c(A,frequency(gas))
A <- c(A,frequency(uspop))
A <- c(A,frequency(sunspots))
TS_Info[,3] <- A


A <- NULL
A <- rbind(A,summary(AirPassengers))
A <- rbind(A,summary(BJsales))
A <- rbind(A,summary(JohnsonJohnson))
A <- rbind(A,summary(LakeHuron))
A <- rbind(A,summary(Nile))
A <- rbind(A,summary(UKgas))
A <- rbind(A,summary(UKDriverDeaths))
A <- rbind(A,summary(USAccDeaths))
A <- rbind(A,summary(WWWusage))
A <- rbind(A,summary(airmiles))
A <- rbind(A,summary(austres))
A <- rbind(A,summary(co2))
A <- rbind(A,summary(discoveries))
A <- rbind(A,summary(lynx))
A <- rbind(A,summary(nhtemp))
A <- rbind(A,summary(nottem))
A <- rbind(A,summary(presidents,na.rm=TRUE)[1:6])
A <- rbind(A,summary(treering))
A <- rbind(A,summary(gas))
A <- rbind(A,summary(uspop))
A <- rbind(A,summary(sunspots))

TS_Info[,4:9] <- A

write.csv(TS_Info,"TS_Info.csv",row.names=F)







get_MAPE(AirPassengers)
get_MAPE(BJsales)
get_MAPE(EuStockMarkets)
get_MAPE(JohnsonJohnson)
get_MAPE(LakeHuron)
get_MAPE(Nile)
get_MAPE(UKgas)
get_MAPE(UKDriverDeaths)
get_MAPE(UKLungDeaths)
get_MAPE(USAccDeaths)
get_MAPE(WWWusage)
get_MAPE(airmiles)
get_MAPE(austres)
get_MAPE(co2)
get_MAPE(discoveries)
get_MAPE(lynx)
get_MAPE(nhtemp)
get_MAPE(nottem)
get_MAPE(presidents)
get_MAPE(treering)
get_MAPE(gas)
get_MAPE(uspop)
get_MAPE(sunspots)

# MAPE Accuracy
library(forecast)

get_MAPE <- function(ts){
  tsname <- deparse(substitute(ts))
  Acc_Mat <- data.frame(TSName = rep(tsname,6),Models=c("ETS","STL","LM","ARIMA","NNETAR","TBATS"),
                        ME=numeric(6),RMSE=numeric(6),MAE=numeric(6),MPE=numeric(6),
                        MAPE=numeric(6),MASE=numeric(6))
  for(i in 1:nrow(Acc_Mat)){
    Acc_Mat[1,3:8] <- accuracy(ets(ts)$fitted,ts)[1:6]
    if(frequency(ts)>1) Acc_Mat[2,3:8] <- accuracy(ts-stl(ts,frequency(ts))$time.series[,3],ts)[1:6] else
      Acc_Mat[2,3:8] <- NA
    Acc_Mat[3,3:8] <- accuracy(fitted(lm(ts~I(1:length(ts)))),ts)[1:6]
    Acc_Mat[4,3:8] <- accuracy(auto.arima(ts)$fitted,ts)[1:6]
    Acc_Mat[5,3:8] <- accuracy(fitted(nnetar(ts)),ts)[1:6]
    Acc_Mat[6,3:8] <- accuracy(fitted(tbats(ts)),ts)[1:6]
  }
  Acc_Mat
}

TSDF <- data.frame(TSName=character(0),Models=character(0),Accuracy=numeric(0))
TSDF <- rbind(TSDF,get_MAPE(AirPassengers))
TSDF <- rbind(TSDF,get_MAPE(BJsales))
TSDF <- rbind(TSDF,get_MAPE(JohnsonJohnson))
TSDF <- rbind(TSDF,get_MAPE(LakeHuron))
TSDF <- rbind(TSDF,get_MAPE(Nile))
TSDF <- rbind(TSDF,get_MAPE(UKgas))
TSDF <- rbind(TSDF,get_MAPE(UKDriverDeaths))
TSDF <- rbind(TSDF,get_MAPE(USAccDeaths))
TSDF <- rbind(TSDF,get_MAPE(WWWusage))
TSDF <- rbind(TSDF,get_MAPE(airmiles))
TSDF <- rbind(TSDF,get_MAPE(austres))
TSDF <- rbind(TSDF,get_MAPE(co2))
TSDF <- rbind(TSDF,get_MAPE(discoveries))
TSDF <- rbind(TSDF,get_MAPE(lynx))
TSDF <- rbind(TSDF,get_MAPE(nhtemp))
TSDF <- rbind(TSDF,get_MAPE(nottem))
TSDF <- rbind(TSDF,get_MAPE(presidents))
TSDF <- rbind(TSDF,get_MAPE(treering))
TSDF <- rbind(TSDF,get_MAPE(gas))
TSDF <- rbind(TSDF,get_MAPE(uspop))
TSDF <- rbind(TSDF,get_MAPE(sunspots))
TSDF

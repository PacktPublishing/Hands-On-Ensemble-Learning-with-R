
plotts <- function(ts){
  tf <- frequency(ts)
  if(tf<=1) plot.ts(ts) else
    {
      beginy <- start(ts)[1]; endy <- end(ts)[1]
      plot(x=NULL,y=NULL,ylim=range(ts),xlim=c(1,tf),
              ylab="Time Series",xlab="Time","l",col=1)
      points(start(ts)[2]:tf,window(ts,start=start(ts),end=c(beginy,tf)),
             col=beginy,"l")
      for(i in (beginy+1):(endy-1)){
        points(1:tf,window(ts,start=c(i,1),end=c(i,tf)),col=i,"l")
      }
      points(1:end(ts)[2],window(ts,start=c(endy,1),end=end(ts)),
             col=endy,"l")
    }
}




get_MAPE <- function(ts){
  Acc_Mat <- data.frame(Models=c("ETS","STL","LM","ARIMA","NNETAR","TBATS"),
                        Accuracy=numeric(6))
  for(i in 1:nrow(Acc_Mat)){
    Acc_Mat[1,2] <- accuracy(ets(ts)$fitted,ts)[5]
    if(frequency(ts)>1) Acc_Mat[2,2] <- accuracy(ts-stl(ts,frequency(ts))$time.series[,3],ts)[5] else
      Acc_Mat[2,2] <- NA
    Acc_Mat[3,2] <- accuracy(fitted(lm(ts~I(1:length(ts)))),ts)[5]
    Acc_Mat[4,2] <- accuracy(auto.arima(ts)$fitted,ts)[5]
    Acc_Mat[5,2] <- accuracy(fitted(nnetar(ts)),ts)[5]
    Acc_Mat[6,2] <- accuracy(fitted(tbats(ts)),ts)[5]
  }
  Acc_Mat
}


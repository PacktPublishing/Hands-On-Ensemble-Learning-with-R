library(class)
library(factoextra)
library(gridExtra)
library(ipred)
library(kernlab)
library(missForest)
library(mlbench)
library(randomForest)
library(randomForestExplainer)

setwd("C:/Users/tprabhan/Documents/My_Books/ELwR/R_Programs/Chapter_04/SRC")
#setwd("/home/pranathi/Documents/ELwR/R_Programs/Chapter_04/SRC")
source("Utilities.R")

# Common Number of Observations for Two Bootstrap Samples
N <- seq(1e3,1e4,1e3)
N
B <- 1e2
Common_Prob <- NULL
index <- 1
for(i in N){
  temp_prob <- NULL
  for(j in 1:B){
    s1 <- sample(i,size=i,replace=TRUE)
    s2 <- sample(i,size=i,replace=TRUE)
    temp_prob <- c(temp_prob,length(intersect(s1,s2))/i)
  }
  Common_Prob[index] <- mean(temp_prob)
  index <- index + 1
}
Common_Prob


# German Credit Data 
load("../Data/GC2.RData")
set.seed(12345)
Train_Test <- sample(c("Train","Test"),nrow(GC2),replace = TRUE,prob = c(0.7,0.3))
GC2_Train <- GC2[Train_Test=="Train",]
GC2_TestX <- within(GC2[Train_Test=="Test",],rm(good_bad))
GC2_TestY <- GC2[Train_Test=="Test","good_bad"]
GC2_Formula <- as.formula("good_bad~.")

GC2_RF <- randomForest(GC2_Formula,data=GC2_Train,
                       ntree=500)
GC2_RF_Margin <- predict(GC2_RF,newdata = GC2_TestX,
                      type="class")
sum(GC2_RF_Margin==GC2_TestY)/313

GC2_RF2 <- randomForest(GC2_Formula,data=GC2_Train,mtry=8,
                        ntree=500)
GC2_RF2_Margin <- predict(GC2_RF2,newdata = GC2_TestX,
                          type="class")
sum(GC2_RF2_Margin==GC2_TestY)/313

windows(height=100,width=100)
plot(GC2_RF2)
GC2_RF2.legend <- colnames(GC2_RF2$err.rate)
legend(x=300,y=0.5,legend = GC2_RF2.legend,lty=c(1,2,3), col=c(1,2,3))
head(GC2_RF2$err.rate,10)

GC2_RF3 <- randomForest(GC2_Formula,data=GC2_Train,mtry=10,
                        #minsplit=10,minbucket=5,
                        parms = list(split="information",
                                     loss=matrix(c(0,1,1000,0),byrow = TRUE,nrow=2)),
                        ntree=1000)
GC2_RF3_Margin <- predict(GC2_RF3,newdata = GC2_TestX,
                          type="class")
sum(GC2_RF3_Margin==GC2_TestY)/313
windows(height=100,width=100)
plot(GC2_RF3)
GC2_RF3.legend <- colnames(GC2_RF3$err.rate)
legend(x=300,y=0.5,legend = GC2_RF3.legend,lty=c(1,2,3), col=c(1,2,3))
max(GC2_RF3$err.rate)


# Visualize the random forest
pdf("GC_Random_Forest.pdf",height=5,width=10)
plot_RF(GC2_RF)
dev.off()




# Explore Different Options of RF such as mtry, etc

# Diabetes Dataset
data("PimaIndiansDiabetes")
#PimaIndiansDiabetes$diabetes <- as.character(PimaIndiansDiabetes$diabetes)
set.seed(12345)
Train_Test <- sample(c("Train","Test"),nrow(PimaIndiansDiabetes),replace = TRUE,prob = c(0.7,0.3))
head(Train_Test)
PimaIndiansDiabetes_Train <- PimaIndiansDiabetes[Train_Test=="Train",]
PimaIndiansDiabetes_TestX <- within(PimaIndiansDiabetes[Train_Test=="Test",],
                                    rm(diabetes))
PimaIndiansDiabetes_TestY <- PimaIndiansDiabetes[Train_Test=="Test","diabetes"]
PID_Formula <- as.formula("diabetes~.")

PID_RF <- randomForest(PID_Formula,data=PimaIndiansDiabetes_Train,
                       coob=TRUE,
                       ntree=500,keepX=TRUE,mtry=5,
                       parms=list(prior=c(0.65,0.35)))
PID_RF_Margin <- predict(PID_RF,newdata = PimaIndiansDiabetes_TestX,
                      type="class")
sum(PID_RF_Margin==PimaIndiansDiabetes_TestY)/257


# Variable Importance 
library(rpart)
data(kyphosis)
kc <- rpart(Kyphosis~.,data=kyphosis,maxsurrogate=0)
kc$variable.importance
plot(kc);text(kc)
summary(kc)
varImpPlot(GC2_RF)

windows(height=100,width=200)
par(mfrow=c(1,2))
varImpPlot(GC2_RF,main="Variable Importance plot for \n Random Forest of German Data")
varImpPlot(PID_RF,main="Variable Importance plot for \n Random Forest of Pima Indian Diabetes")


# Promimity in Random Forest
GC2_RF3 <- randomForest(GC2_Formula,data=GC2_Train,
                        ntree=500,proximity=TRUE,cob.prox=TRUE)
GC2_RF3$proximity[1:10,1:10]
# View(GC2_RF3$proximity)
MDSplot(GC2_RF3,fac = GC2_Train$good_bad,
        main="MDS Plot for Proximity Matrix of a RF")
which.max(GC2_RF3$proximity[1,-1])
which.max(GC2_RF3$proximity[2,-2])


# Random Forest Explainer
# https://cran.rstudio.com/web/packages/randomForestExplainer/vignettes/randomForestExplainer.html
# MDD = Minimal depth distribution
GC2_RF_MDD <- min_depth_distribution(GC2_RF) 
head(GC2_RF_MDD)
plot_min_depth_distribution(GC2_RF_MDD,k=nrow(GC2_TestX))

# Variable Importance Measures
GC2_RF_VIM <- measure_importance(GC2_RF)
GC2_RF4 <- randomForest(GC2_Formula,data=GC2_Train,
                       ntree=500,localImp=TRUE)
GC2_RF4_VIM <- measure_importance(GC2_RF4)
GC2_RF4_VIM

# Multi-way Importance Plot

P1 <- plot_multi_way_importance(GC2_RF4_VIM, size_measure = "no_of_nodes",
                          x_measure="mean_min_depth",
                          y_measure = "times_a_root")
P2 <- plot_multi_way_importance(GC2_RF4_VIM, size_measure = "no_of_nodes",
                          x_measure="mean_min_depth",
                          y_measure = "gini_decrease")
P3 <- plot_multi_way_importance(GC2_RF4_VIM, size_measure = "no_of_nodes",
                          x_measure="mean_min_depth",
                          y_measure = "no_of_trees")
P4 <- plot_multi_way_importance(GC2_RF4_VIM, size_measure = "no_of_nodes",
                          x_measure="mean_min_depth",
                          y_measure = "p_value")
grid.arrange(P1,P2,P3,P4, ncol=2)

# ggpairs for the measures correlations
plot_importance_ggpairs(GC2_RF4_VIM)

# Variable Interactions
GC2_RF4_VIN <- important_variables(GC2_RF4, k = 5, 
                                   measures = c("mean_min_depth", "no_of_trees"))
GC2_RF4_VIN_Frame <- min_depth_interactions(GC2_RF4,GC2_RF4_VIN)
head(GC2_RF2_VIN_Frame[order(GC2_RF4_VIN_Frame$occurrences, decreasing = TRUE), ])
plot_min_depth_interactions(GC2_RF4_VIN_Frame)
# Exporting the forest result to an HTML file
explain_forest(GC2_RF2, interactions = TRUE, data = GC2_Train)

# Comparisons with Bagging
data("spam")
set.seed(12345)
Train_Test <- sample(c("Train","Test"),nrow(spam),replace = TRUE,prob = c(0.7,0.3))
head(Train_Test)
spam_Train <- spam[Train_Test=="Train",]
spam_TestX <- within(spam[Train_Test=="Test",],
                     rm(type))
spam_TestY <- spam[Train_Test=="Test","type"]
spam_Formula <- as.formula("type~.")
spam_ct <- rpart(spam_Formula,data=spam_Train)
spam_ct_predict <- predict(spam_ct,newdata=spam_TestX,type="class")
ct_accuracy <- sum(spam_ct_predict==spam_TestY)/nrow(spam_TestX)
ct_accuracy
spam_rf <- randomForest(spam_Formula,data=spam_Train,coob=TRUE,
                        ntree=500,keepX=TRUE,mtry=5)
spam_rf_predict <- predict(spam_rf,newdata=spam_TestX,type="class")
rf_accuracy <- sum(spam_rf_predict==spam_TestY)/nrow(spam_TestX)
rf_accuracy
spam_bag <- randomForest(spam_Formula,data=spam_Train,coob=TRUE,
                         ntree=500,keepX=TRUE,mtry=ncol(spam_TestX))
spam_bag_predict <- predict(spam_bag,newdata=spam_TestX,type="class")
bag_accuracy <- sum(spam_bag_predict==spam_TestY)/nrow(spam_TestX)
bag_accuracy
windows(height=100,width=200)
par(mfrow=c(1,2))
plot(spam_rf,main="Random Forest for Spam Classification")
plot(spam_bag,main="Bagging for Spam Classification")


# Miss data imputation with missForest
# Data from https://openmv.net/info/travel-times
TT <- read.csv("../Data/Travel_Times.csv")
dim(TT)
sum(is.na(TT))
sapply(TT,function(x) sum(is.na(x)))
TT$FuelEconomy

TT_Missing <- missForest(TT[,-c(1,2,12)],
                         maxiter = 10,ntree=500,mtry=6)
TT_FuelEconomy <- cbind(TT_Missing$ximp[,7],TT$FuelEconomy)


# Clustering with Random Forest
data(multishapes)
par(mfrow=c(1,2))
plot(multishapes[1:2],col=multishapes[,3], 
     main="Six Multishapes Data Display")
MS_RF <- randomForest(x=multishapes[1:2],y=NULL,ntree=1000,proximity=TRUE,
                      oob.prox=T,mtry = 1)
MS_hclust <- hclust(as.dist(1-MS_RF$proximity),method="ward.D2")
MS_RF_clust <- cutree(MS_hclust,k=6)
table(MS_RF_clust,multishapes$shape)
plot(multishapes[1:2],col=MS_RF_clust,
     main="Clustering with Random Forest")

